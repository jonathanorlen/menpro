<?php

$t = $this->db->get_where('opsi_hproject',array('kode_histori'=>@$paramopsi));
$produksi = $t->result();

$nomor = 1;  $total = 0;

foreach($produksi as $daftar){

  ?> 
  <tr style="font-size: 15px;">
    <td><?php echo $nomor; ?></td>
    <input type="hidden" id="id" name="id" value="<?php echo @$daftar->id; ?>" />
    <td><?php echo @$daftar->modul; ?></td>
    <td><?php echo @$daftar->submodul; ?></td>
    <td><?php echo @$daftar->fitur; ?></td>
    <td><?php echo @$daftar->keterangan; ?></td>
    <td align="center"><?php echo get_edit_del_id(@$daftar->id); ?></td>
  </tr>

  <?php 

  $nomor++; 
} 

?>
