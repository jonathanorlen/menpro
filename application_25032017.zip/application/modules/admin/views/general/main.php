<script src="<?php echo base_url() . 'component/js/jquery.js '?>" type="text/javascript"></script>


<?php echo $this->load->view('general/header'); ?>
<?php echo $this->load->view('general/sidebar'); ?>
<?php echo $konten;?>
<?php echo $this->load->view('general/footer'); ?>

